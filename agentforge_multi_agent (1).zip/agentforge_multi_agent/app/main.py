import os
import time
from pathlib import Path

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

load_dotenv()
ROOT = Path(__file__).resolve().parent.parent
STATIC = ROOT / "static"

app = FastAPI(title="AgentForge API", description="CrewAI multi-agent report workspace", version="1.0.0")
app.mount("/static", StaticFiles(directory=str(STATIC)), name="static")

class RunRequest(BaseModel):
    topic: str = Field(min_length=3, max_length=300)
    goal: str = Field(min_length=3, max_length=600)
    audience: str = Field(min_length=2, max_length=200)

class RunResponse(BaseModel):
    report: str
    elapsed_seconds: float

@app.get("/", include_in_schema=False)
def index():
    return FileResponse(STATIC / "index.html")

@app.get("/api/health")
def health():
    return {"status": "ok", "service": "AgentForge API"}

@app.post("/api/run", response_model=RunResponse)
def run_agents(payload: RunRequest):
    if not os.getenv("OPENAI_API_KEY"):
        raise HTTPException(status_code=503, detail="OPENAI_API_KEY is missing. Add it to .env and restart.")
    from app.crew import run_crew
    started = time.perf_counter()
    try:
        report = run_crew(payload.topic.strip(), payload.goal.strip(), payload.audience.strip())
        return RunResponse(report=report, elapsed_seconds=round(time.perf_counter() - started, 2))
    except Exception as exc:
        print(f"Agent execution failed: {type(exc).__name__}: {exc}")
        raise HTTPException(status_code=500, detail="Agent workflow failed. Check server logs, API key, quota, model, and package versions.") from exc
