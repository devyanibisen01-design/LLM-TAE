import os
from crewai import Agent, Crew, Process, Task

def run_crew(topic: str, goal: str, audience: str) -> str:
    model = os.getenv("CREWAI_MODEL", "openai/gpt-4o-mini")

    researcher = Agent(
        role="Research Specialist",
        goal="Organize useful background knowledge about {topic}.",
        backstory="You structure knowledge carefully, distinguish assumptions from facts, and never invent sources or statistics.",
        llm=model, verbose=False, allow_delegation=False,
    )
    analyst = Agent(
        role="Critical Analyst",
        goal="Evaluate the research and identify insights relevant to {goal}.",
        backstory="You examine evidence, limitations, trade-offs, risks, and practical implications.",
        llm=model, verbose=False, allow_delegation=False,
    )
    writer = Agent(
        role="Report Writer",
        goal="Create a clear, actionable report for {audience}.",
        backstory="You are a careful technical writer who produces structured, readable reports.",
        llm=model, verbose=False, allow_delegation=False,
    )

    research_task = Task(
        description=(
            "Prepare a research brief about {topic}. Goal: {goal}. Audience: {audience}. "
            "Cover core concepts, key themes, applications, limitations, and open questions. "
            "Do not fabricate citations or claim live web research."
        ),
        expected_output="Structured brief with overview, themes, applications, limitations, and open questions.",
        agent=researcher,
    )
    analysis_task = Task(
        description=(
            "Critically evaluate the previous research brief for the goal {goal} and audience {audience}. "
            "Identify insights, risks, trade-offs, recommendations, and claims requiring verification."
        ),
        expected_output="Critical analysis with insights, risks, trade-offs, and prioritized recommendations.",
        agent=analyst, context=[research_task],
    )
    writing_task = Task(
        description=(
            "Write the final report on {topic} for {audience}, fulfilling this goal: {goal}. "
            "Integrate the research and analysis. Use Markdown headings, executive summary, key findings, "
            "limitations, recommendations, and conclusion. Do not invent references or claim live web research."
        ),
        expected_output="Polished Markdown report.",
        agent=writer, context=[research_task, analysis_task],
    )
    crew = Crew(
        agents=[researcher, analyst, writer],
        tasks=[research_task, analysis_task, writing_task],
        process=Process.sequential,
        verbose=False,
    )
    result = crew.kickoff(inputs={"topic": topic, "goal": goal, "audience": audience})
    return str(result)
