const form=document.getElementById("run-form");
const runButton=document.getElementById("run-button");
const buttonText=document.getElementById("button-text");
const errorBox=document.getElementById("error");
const loading=document.getElementById("loading");
const resultSection=document.getElementById("result-section");
const reportBox=document.getElementById("report");
let latestReport="";

form.addEventListener("submit",async event=>{
  event.preventDefault();errorBox.hidden=true;resultSection.hidden=true;loading.hidden=false;
  runButton.disabled=true;buttonText.textContent="Agents are working…";
  const payload={
    topic:document.getElementById("topic").value.trim(),
    goal:document.getElementById("goal").value.trim(),
    audience:document.getElementById("audience").value.trim()
  };
  try{
    const response=await fetch("/api/run",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)});
    const data=await response.json();
    if(!response.ok)throw new Error(data.detail||`Request failed (${response.status})`);
    latestReport=data.report||"";reportBox.textContent=latestReport;
    document.getElementById("elapsed").textContent=`Completed in ${data.elapsed_seconds} seconds`;
    resultSection.hidden=false;resultSection.scrollIntoView({behavior:"smooth",block:"start"});
  }catch(err){errorBox.textContent=err.message||"Something went wrong. Check the server terminal.";errorBox.hidden=false}
  finally{loading.hidden=true;runButton.disabled=false;buttonText.textContent="Run agent team"}
});
document.getElementById("copy").addEventListener("click",async()=>{
  if(!latestReport)return;
  try{await navigator.clipboard.writeText(latestReport);document.getElementById("copy").textContent="Copied!"}
  catch{document.getElementById("copy").textContent="Copy unavailable"}
  setTimeout(()=>document.getElementById("copy").textContent="Copy",1500);
});
document.getElementById("download").addEventListener("click",()=>{
  if(!latestReport)return;
  const url=URL.createObjectURL(new Blob([latestReport],{type:"text/markdown;charset=utf-8"}));
  const a=document.createElement("a");a.href=url;a.download="agentforge-report.md";document.body.appendChild(a);a.click();a.remove();URL.revokeObjectURL(url);
});
