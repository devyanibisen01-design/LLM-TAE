# AgentForge — Multi-Agent AI Workspace

A FastAPI + CrewAI web application. Three agents work sequentially: Research Specialist, Critical Analyst, and Report Writer.

## Requirements
- Python 3.10–3.13
- OpenAI API key with API access/quota

## Windows PowerShell
```powershell
cd agentforge_multi_agent
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
Copy-Item .env.example .env
notepad .env
uvicorn app.main:app --reload
```
Edit `.env` and replace the placeholder with your real key. Then open http://127.0.0.1:8000.

## macOS/Linux
```bash
cd agentforge_multi_agent
python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
cp .env.example .env
# Edit .env and add OPENAI_API_KEY
uvicorn app.main:app --reload
```

## API
`POST /api/run` accepts:
```json
{"topic":"Responsible AI in education","goal":"Explain risks and recommendations","audience":"University students"}
```
Other endpoints: `GET /api/health`, interactive API docs at `/docs`.

## Notes
The researcher agent does not perform live web searches or verify citations. Do not treat generated output as verified research. Model calls may incur API charges. Never commit `.env` or expose your API key in frontend code. Before public deployment, add authentication, rate limiting, timeouts, monitoring, and privacy controls.

CrewAI documentation: https://docs.crewai.com/en/installation
FastAPI static files: https://fastapi.tiangolo.com/tutorial/static-files/
